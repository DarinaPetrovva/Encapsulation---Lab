﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PersonsInfo
{
    public class Person
    {
        private string firstName;
        private string lastName;
        private int age;
        private decimal salary;


        public string FirstName
        {
            get { return firstName; }
             set
            {

                if (value.Length < 3)
                {
                    throw new ArgumentException("Last name cannot contain fewer than 3 symbols! ");
                }

                else { firstName = value; }
                
            }

        }
        public string LastName
        {
           get { return lastName; }
           set
            {
                if (value.Length < 3)
                {
                    throw new ArgumentException("Last name cannot contain fewer than 3 symbols! ");
                }

                else { lastName = value; }
                
            }

        }
        public int Age
        {
            get { return age; }
            set
            {
                if (age <= 0)
                {
                    throw new ArgumentException("Age cannot be zero or a negative integer!");
                }

                else { age = value; }
                
            }

        }

        public decimal Salary
        {
            get { return salary; }
            set
            {

                if (salary < 460)
                {
                    throw new ArgumentException("Salary cannot be less than 460 leva!");

                }
                else { salary = value; }
                
            }


        }



        public void IncreaseSalary(decimal percentage)
        {
           
           
                salary += salary * percentage / 200;
            
        }

        public Person(string firstname, string lastname, int age, decimal salary)
        {
            FirstName = firstname;
            LastName = lastname;
            Age = age;
            Salary = salary;


        }

        public override string ToString()
        {
            return $"{FirstName} {LastName} receives {Salary:f2} leva. ";
        }
    }
}

